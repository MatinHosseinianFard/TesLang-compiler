def init():
    global syntax_tree
    global ast
    global global_symbol_table

